<?php
/**
 * RSS管理 - 后台类
 * 菜单、设置页渲染、表单处理、AJAX 即时开关。
 *
 * @package FGWRS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class FGWRS_Admin {

	const SLUG = 'fgw-rss-manager';

	/**
	 * 注册 hooks。
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_init', array( __CLASS__, 'save_settings' ) );
		// AJAX
		add_action( 'wp_ajax_fgwrss_toggle', array( __CLASS__, 'ajax_toggle' ) );
	}

	/**
	 * 后台菜单（放在"设置"下）。
	 */
	public static function menu() {
		add_submenu_page(
			'options-general.php',
			'RSS管理',
			'RSS管理',
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * 资源加载。
	 */
	public static function assets( $hook ) {
		if ( 'settings_page_' . self::SLUG !== $hook ) {
			return;
		}
		wp_enqueue_style( 'fgwrs-admin', FGWRS_URL . 'assets/admin.css', array(), FGWRS_VER );
		wp_enqueue_script( 'fgwrs-admin', FGWRS_URL . 'assets/admin.js', array( 'jquery' ), FGWRS_VER, true );
		wp_localize_script( 'fgwrs-admin', 'fgwrs', array(
			'ajax'  => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'fgwrs_nonce' ),
		) );
	}

	/**
	 * 渲染设置页（AJAX 即时持久化，无需独立保存按钮）。
	 */
	public static function render() {
		$s = FGWRS_Core::get();
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<div class="wrap fgwrs-wrap">
			<h1>RSS管理 <span class="fgwrs-ver">v<?= FGWRS_VER ?></span></h1>
			<p class="fgwrs-tip">切换开关即时生效并自动保存。</p>

			<div class="fgwrs-card">
				<div class="fgwrs-card-head">
					<h2>总控</h2>
					<button type="button" class="fgwrs-toggle" data-key="enabled">
						<span class="fgwrs-switch <?= ! empty( $s['enabled'] ) ? 'on' : '' ?>"></span>
						<span class="fgwrs-switch-label">启用 RSS</span>
					</button>
				</div>
				<p class="fgwrs-desc">总开关关闭时，下方所有细项自动失效、全站 RSS 全部禁用。</p>
			</div>

			<div class="fgwrs-card">
				<h2>Feed 端点开关</h2>
				<div class="fgwrs-grid">
					<?php
					$items = array(
						'feed_posts'    => '文章 Feed（/feed/ · ?feed=rss2 · /rss）',
						'feed_single'   => '单文章 Feed（/文章ID（如100）.html/feed/）',
						'feed_category' => '分类 Feed（/category/jc/feed/）',
						'feed_tag'      => '标签 Feed（/?tag=标签&feed=rss2）',
						'feed_author'   => '作者 Feed（/?author=作者id（如1）&feed=rss2）',
						'feed_archive'  => '归档 Feed（/date/年（如2026）/月（如01）/feed/ · ?m=年月（如：202601）&feed=rss2）',
						'feed_comments' => '评论 Feed（/comments/feed/ · /文章ID（如100）.html/feed/）',
						'feed_search'   => '搜索 Feed（/?s=分类&feed=rss2）',
						'feed_forum'    => '论坛帖 Feed（/feed/?post_type=forum_post）',
					);
					foreach ( $items as $k => $label ) {
						?>
						<label class="fgwrs-row" data-key="<?= $k ?>">
							<button type="button" class="fgwrs-toggle sm" data-key="<?= $k ?>">
								<span class="fgwrs-switch sm <?= ! empty( $s[ $k ] ) ? 'on' : '' ?>"></span>
							</button>
							<span class="fgwrs-label"><?= $label ?></span>
						</label>
						<?php
					}
					?>
				</div>
			</div>

			<div class="fgwrs-card">
				<h2>输出格式</h2>
				<p class="fgwrs-desc">控制允许使用的 feed 输出格式（浏览器自动发现或 ?feed_type 参数触发）。</p>
				<div class="fgwrs-grid">
					<?php
					$fmts = array(
						'format_rss2' => 'RSS 2.0（默认）',
						'format_atom' => 'Atom',
						'format_rdf'  => 'RDF（RSS 1.0）',
					);
					foreach ( $fmts as $k => $label ) {
						?>
						<label class="fgwrs-row" data-key="<?= $k ?>">
							<button type="button" class="fgwrs-toggle sm" data-key="<?= $k ?>">
								<span class="fgwrs-switch sm <?= ! empty( $s[ $k ] ) ? 'on' : '' ?>"></span>
							</button>
							<span class="fgwrs-label"><?= $label ?></span>
						</label>
						<?php
					}
					?>
				</div>
			</div>

			<div class="fgwrs-card">
				<h2>前端行为</h2>
				<div class="fgwrs-grid">
					<label class="fgwrs-row" data-key="header_link">
						<button type="button" class="fgwrs-toggle sm" data-key="header_link">
							<span class="fgwrs-switch sm <?= ! empty( $s['header_link'] ) ? 'on' : '' ?>"></span>
						</button>
						<span class="fgwrs-label">页头 &lt;link rel="alternate"&gt; 自动发现标签</span>
					</label>
					<label class="fgwrs-row" data-key="redirect_off">
						<button type="button" class="fgwrs-toggle sm" data-key="redirect_off">
							<span class="fgwrs-switch sm <?= ! empty( $s['redirect_off'] ) ? 'on' : '' ?>"></span>
						</button>
						<span class="fgwrs-label">被禁用的 feed 访问时重定向到首页（关闭则 404）</span>
					</label>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * 处理表单提交（持久化）。
	 */
	public static function save_settings() {
		register_setting( 'fgwrs', FGWRS_Core::OPT, array(
			'sanitize_callback' => array( 'FGWRS_Core', 'sanitize' ),
		) );
	}

	/**
	 * AJAX 即时开关：切换某个键并直接持久化（无需再点保存）。
	 */
	public static function ajax_toggle() {
		check_ajax_referer( 'fgwrs_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'msg' => '权限不足' ) );
		}
		$key   = isset( $_POST['key'] ) ? sanitize_key( $_POST['key'] ) : '';
		$value = ! empty( $_POST['on'] );

		$defaults = FGWRS_Core::defaults();
		if ( ! array_key_exists( $key, $defaults ) ) {
			wp_send_json_error( array( 'msg' => '未知设置项' ) );
		}

		// 基于“原始存储值”（不含运行时强制逻辑）合并，避免把总开关的强制 0 写回数据库
		$saved     = get_option( FGWRS_Core::OPT, array() );
		$s         = is_array( $saved ) ? array_merge( $defaults, $saved ) : $defaults;
		$s[ $key ] = $value ? 1 : 0;

		update_option( FGWRS_Core::OPT, $s );
		wp_send_json_success( array( 'key' => $key, 'on' => $value, 'settings' => $s ) );
	}
}
