<?php
/**
 * RSS管理 - 核心类
 * 负责设置存取、hooks 注册、feed 拦截与重定向。
 *
 * @package FGWRS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class FGWRS_Core {

	const VER = '1.1.1';
	const OPT = 'fgwrss_settings';

	/** @var array 当前设置（含默认值） */
	private static $settings = array();

	/**
	 * 默认设置。
	 * 总开关 off（全部启用）。各细项默认 on。
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'enabled'          => 1, // 总开关：1 启用 RSS，0 禁用全部
			'feed_posts'       => 1, // 文章 feed（/feed）
			'feed_single'      => 1, // 单文章 feed（/postid/feed）
			'feed_category'    => 1, // 分类 feed
			'feed_tag'         => 1, // 标签 feed
			'feed_author'      => 1, // 作者 feed
			'feed_archive'     => 1, // 归档 feed（年/月/日）
			'feed_comments'    => 1, // 评论 feed（/comments/feed）
			'feed_search'      => 1, // 搜索 feed（?s=xx&feed=rss2）
			'feed_forum'       => 1, // 论坛帖 feed（?post_type=forum_post&feed=rss2）
			'format_rss2'      => 1, // 允许 RSS 2.0 输出
			'format_atom'      => 1, // 允许 Atom 输出
			'format_rdf'       => 1, // 允许 RDF 输出
			'header_link'      => 1, // 页头 <link rel="alternate"> 标签
			'redirect_off'     => 1, // 被禁用的 feed 访问时重定向到首页（0=404）
		);
	}

	/**
	 * 读取设置（合并默认值）。
	 *
	 * @return array
	 */
	public static function get() {
		if ( ! empty( self::$settings ) ) {
			return self::$settings;
		}
		$saved    = get_option( self::OPT, array() );
		$defaults = self::defaults();
		$merged   = is_array( $saved ) ? array_merge( $defaults, $saved ) : $defaults;

		// 总开关关闭时，强制所有细项为 0（全部禁用）
		if ( empty( $merged['enabled'] ) ) {
			$forced_off = array(
				'feed_posts', 'feed_single', 'feed_category', 'feed_tag',
				'feed_author', 'feed_archive', 'feed_comments', 'feed_search', 'feed_forum',
				'format_rss2', 'format_atom', 'format_rdf', 'header_link',
			);
			foreach ( $forced_off as $k ) {
				$merged[ $k ] = 0;
			}
		}

		self::$settings = $merged;
		return $merged;
	}

	/**
	 * 保存设置。
	 *
	 * @param array $data 提交数据。
	 */
	public static function save( $data ) {
		$defaults = self::defaults();
		$new      = array_intersect_key( $data, $defaults );
		// 数值化
		foreach ( $new as $k => $v ) {
			$new[ $k ] = $v ? 1 : 0;
		}
		$saved  = get_option( self::OPT, array() );
		$base   = is_array( $saved ) ? array_merge( $defaults, $saved ) : $defaults;
		$merged = array_merge( $base, $new );
		update_option( self::OPT, $merged );
		self::$settings = array(); // 清空缓存，下次 get() 重新读取
	}

	/**
	 * 表单 sanitize（register_setting 用）。
	 * 把标准键存到 option 的自定义部分。
	 *
	 * @param array $input 原始输入。
	 * @return array
	 */
	public static function sanitize( $input ) {
		$existing = get_option( self::OPT, array() );
		$new      = self::sanitize_submit( $input );
		return array_merge( $existing, $new );
	}

	/**
	 * 把提交数据数值化（仅保留已知键）。
	 *
	 * @param array $data 数据。
	 * @return array
	 */
	public static function sanitize_submit( $data ) {
		$defaults = self::defaults();
		$new      = array_intersect_key( $data, $defaults );
		foreach ( $new as $k => $v ) {
			$new[ $k ] = $v ? 1 : 0;
		}
		return $new;
	}

	/**
	 * 某个 feed 项是否启用（同时受总开关约束）。
	 *
	 * @param string $key 设置键。
	 * @return bool
	 */
	public static function is_on( $key ) {
		$s = self::get();
		if ( empty( $s['enabled'] ) ) {
			return false;
		}
		return ! empty( $s[ $key ] );
	}

	/**
	 * 某输出格式是否启用。
	 *
	 * @param string $format rss2|atom|rdf。
	 * @return bool
	 */
	public static function format_ok( $format ) {
		$map = array(
			'rss'  => 'format_rss2',
			'rss2' => 'format_rss2',
			'atom' => 'format_atom',
			'rdf'  => 'format_rdf',
		);
		$key = isset( $map[ $format ] ) ? $map[ $format ] : 'format_rss2';
		return self::is_on( $key );
	}

	/**
	 * 判断当前请求是 WordPress feed 端点，并解析出类型。
	 *
	 * @return string 类型键：feed_posts/feed_single/... 或 ''（非 feed）
	 */
	public static function detect_feed_type() {
		// 是否处于 feed 页
		$is_feed = (bool) apply_filters( 'fgwrss_is_feed', is_feed() );
		if ( ! $is_feed && ! isset( $_GET['feed'] ) && ! isset( $_GET['feed_type'] ) ) {
			return '';
		}

		// 论坛帖（子比 forum_post CPT）走独立端点，优先识别
		if ( isset( $_GET['post_type'] ) && ! empty( $_GET['post_type'] ) ) {
			return 'feed_forum';
		}
		// 搜索 feed（?s=xx&feed=xx）
		if ( isset( $_GET['s'] ) && '' !== (string) $_GET['s'] ) {
			return 'feed_search';
		}
		if ( is_comment_feed() ) {
			return 'feed_comments';
		}
		if ( is_single() ) {
			return 'feed_single';
		}
		if ( is_category() ) {
			return 'feed_category';
		}
		if ( is_tag() ) {
			return 'feed_tag';
		}
		if ( is_author() ) {
			return 'feed_author';
		}
		if ( is_date() ) {
			return 'feed_archive';
		}
		// 主 feed / 全量 feed（is_front_feed / is_feed 兜底）
		return 'feed_posts';
	}

	/**
	 * 当前请求的 feed 类型是否被禁用。
	 *
	 * @return bool
	 */
	public static function feed_disabled() {
		$type = self::detect_feed_type();
		if ( '' === $type ) {
			return false;
		}
		return ! self::is_on( $type );
	}

	/**
	 * 插件入口：加载核心 hooks。
	 */
	public static function init() {
		$s = self::get();

		// 若总开关关闭或存在被禁用的项，才拦截 feed 端点
		// 通过 template_redirect 在 feed 输出前判断
		add_action( 'template_redirect', array( __CLASS__, 'intercept_feed' ), 5 );

		// 移除页头 <link rel="alternate" type="application/rss+xml"> 等标签
		if ( ! self::is_on( 'header_link' ) ) {
			remove_action( 'wp_head', 'feed_links', 2 );
			remove_action( 'wp_head', 'feed_links_extra', 3 );
			remove_action( 'wp_head', 'rsd_link' );
		}

		// 输出格式控制：当某格式被禁用，通过修改 feed 的默认类型/拦截
		add_filter( 'feed_links', array( __CLASS__, 'filter_feed_links' ), 20 );

		// 让"输出格式"开关真正拦截对应格式请求（此前形同虚设）
		add_action( 'template_redirect', array( __CLASS__, 'intercept_format' ), 6 );
	}

	/**
	 * 拦截被禁用的 feed 端点：重定向或 404。
	 * 仅在当前请求确为 feed 端点时介入，普通页面请求一律放行。
	 */
	public static function intercept_feed() {
		if ( '' === self::detect_feed_type() ) {
			return; // 非 feed 请求，绝不干预（避免误伤全站页面）
		}
		if ( ! self::feed_disabled() ) {
			return;
		}
		self::deny();
	}

	/**
	 * 拦截被禁用的输出格式请求（如关闭 Atom 后，/feed/atom 与 ?feed=atom 均 404/重定向）。
	 * 仅在当前请求确为 feed 端点时介入。
	 */
	public static function intercept_format() {
		$s = self::get();
		if ( empty( $s['enabled'] ) ) {
			return; // 总开关已由 intercept_feed 处理
		}
		if ( '' === self::detect_feed_type() ) {
			return; // 非 feed 请求不干预
		}
		if ( ! self::format_ok( self::current_format() ) ) {
			self::deny();
		}
	}

	/**
	 * 对已判定为「应禁用的 feed 请求」执行拒绝：管理员放行，其余重定向或 404。
	 */
	private static function deny() {
		if ( current_user_can( 'manage_options' ) ) {
			return; // 管理员可见，便于排查
		}
		$s = self::get();
		if ( ! empty( $s['redirect_off'] ) ) {
			wp_safe_redirect( home_url( '/' ), 302 );
		} else {
			status_header( 404 );
			nocache_headers();
			header( 'Content-Type: text/html; charset=utf-8' );
			echo '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>404 Not Found</title></head><body><h1>404 Not Found</h1><p>该订阅源已被关闭。</p></body></html>';
		}
		exit;
	}

	/**
	 * 当前请求的 feed 格式（rss / atom / rdf）。
	 * 优先看 ?feed_type，其次看 ?feed，最后看 PATH_INFO 中 /feed/<fmt>/。
	 */
	public static function current_format() {
		if ( isset( $_GET['feed_type'] ) ) {
			return sanitize_key( wp_unslash( $_GET['feed_type'] ) );
		}
		if ( isset( $_GET['feed'] ) ) {
			$got = sanitize_key( wp_unslash( $_GET['feed'] ) );
			$map = array(
				'rss'  => 'rss',
				'rss2' => 'rss',
				'rss2.0' => 'rss',
				'rss0.92' => 'rdf',
				'atom' => 'atom',
			);
			return isset( $map[ $got ] ) ? $map[ $got ] : $got;
		}
		// PATH_INFO 形如 /feed/atom/ 或 /feed/rss2/
		$pi = '';
		if ( ! empty( $_SERVER['REQUEST_URI'] ) ) {
			$pi = sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) );
		}
		if ( preg_match( '#/feed/(rss|rss2|atom|rdf)/?$#i', $pi, $m ) ) {
			$fmt = strtolower( $m[1] );
			return ( 'rss2' === $fmt ) ? 'rss' : $fmt;
		}
		return 'rss'; // 默认
	}

	/**
	 * 过滤页头 feed 链接：移除被禁用类型的 alternate 标签。
	 *
	 * @param array $links 现有链接。
	 * @return array
	 */
	public static function filter_feed_links( $links ) {
		if ( self::is_on( 'header_link' ) ) {
			return $links;
		}
		// 总开关关闭或 header_link 关闭：清空所有
		return array();
	}

	/**
	 * 激活：写入默认设置。
	 */
	public static function activate() {
		if ( ! get_option( self::OPT ) ) {
			update_option( self::OPT, self::defaults() );
		}
	}

	/**
	 * 停用：删除设置。
	 */
	public static function deactivate() {
		delete_option( self::OPT );
	}
}
