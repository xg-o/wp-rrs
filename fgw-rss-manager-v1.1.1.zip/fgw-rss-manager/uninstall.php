<?php
/**
 * RSS管理 - 卸载
 * 删除插件设置。
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
delete_option( 'fgwrss_settings' );
