<?php
/**
 * Plugin Name:       RSS管理
 * Plugin URI:        https://fgwl.qzz.io
 * Description:       统一管理 WordPress 系统自带 RSS：总开关一键禁用/启用，细粒度控制文章/分类/标签/作者/归档/评论 feed，控制 RSS 2.0/Atom/RDF 输出格式，移除页头 <link rel="alternate"> 标签，被禁用的 feed 端点可重定向到首页。适用所有主题，已验证主题：子比主题。插件由AI生成。
 * Version:           1.1.1
 * Author:            行简
 * Author URI:        https://fgwl.qzz.io
 * License:           GPL v2 or later
 * Text Domain:       fgw-rss-manager
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // 禁止直接访问
}

define( 'FGWRS_VER', '1.1.1' );
define( 'FGWRS_FILE', __FILE__ );
define( 'FGWRS_DIR', plugin_dir_path( __FILE__ ) );
define( 'FGWRS_URL', plugin_dir_url( __FILE__ ) );
define( 'FGWRS_OPT', 'fgwrss_settings' );

require_once FGWRS_DIR . 'includes/class-fgwrs-core.php';
require_once FGWRS_DIR . 'includes/class-fgwrs-admin.php';

register_activation_hook( __FILE__, array( 'FGWRS_Core', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'FGWRS_Core', 'deactivate' ) );

// 启动核心（加载 hooks）
FGWRS_Core::init();

// 后台
if ( is_admin() ) {
	FGWRS_Admin::init();
}
