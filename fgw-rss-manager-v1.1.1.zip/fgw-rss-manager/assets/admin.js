/* RSS管理 - 后台脚本：AJAX 即时开关（以服务端返回为准同步界面） */
jQuery(function ($) {
	$(document).on('click', '.fgwrs-toggle', function () {
		var $btn = $(this);
		var $sw  = $btn.find('.fgwrs-switch');
		var on   = !$sw.hasClass('on');
		var key  = $btn.data('key');

		// 乐观更新
		$sw.toggleClass('on', on);

		$.post(fgwrs.ajax, {
			action: 'fgwrss_toggle',
			nonce: fgwrs.nonce,
			key: key,
			on: on ? 1 : 0
		}, function (resp) {
			if (resp && resp.success && resp.data && resp.data.settings) {
				// 以服务端持久值同步全部开关（避免总开关与细项状态脱节）
				var s = resp.data.settings;
				$('.fgwrs-toggle').each(function () {
					$(this).find('.fgwrs-switch').toggleClass('on', !!s[$(this).data('key')]);
				});
			} else {
				$sw.toggleClass('on'); // 回滚
			}
		}).fail(function () {
			$sw.toggleClass('on'); // 回滚
		});
	});
});
